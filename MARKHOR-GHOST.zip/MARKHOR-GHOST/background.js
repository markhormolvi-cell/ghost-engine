const TRACKING_URL = "https://ghost-bridge-1kuk.vercel.app/api/ghost";
const SECURITY_KEY = "MARKHOR_SECURE_2024";
let currentAuth = null;
let isBlocked = true;
let deviceId = "";
let localIp = "";
let expiryTimer = null;

// Get real IP at startup for comparison
async function refreshLocalIp() {
  try {
    const res = await fetch("https://api.ipify.org?format=json");
    const data = await res.json();
    localIp = data.ip;
    console.log("Local IP detected:", localIp);
  } catch (e) {}
}

async function generateSmartDeviceId() {
  const specs = [navigator.platform, navigator.language, navigator.hardwareConcurrency || "U", (navigator.deviceMemory || "U"), Intl.DateTimeFormat().resolvedOptions().timeZone].join('|');
  let hash = 0;
  for (let i = 0; i < specs.length; i++) { hash = ((hash << 5) - hash) + specs.charCodeAt(i); hash |= 0; }
  return "PC-" + Math.abs(hash).toString(16).toUpperCase();
}

async function runLicenseSync() {
  if (!localIp) await refreshLocalIp();
  return new Promise((resolve) => {
    chrome.storage.local.get(["deviceId", "apiKey"], async (res) => {
      if (!deviceId) {
        deviceId = res.deviceId || await generateSmartDeviceId();
        chrome.storage.local.set({ deviceId });
      }

      const usage = await fetchBandwidthStats(res.apiKey);
      const manifest = chrome.runtime.getManifest();
      const payload = {
        action: "track",
        deviceId: deviceId,
        ip: localIp,
        location: "MARKHOR GHOST MODE",
        pcDetails: `${navigator.platform} | ${navigator.hardwareConcurrency} Cores`,
        bandwidth: usage,
        version: manifest.version
      };

      try {
        const response = await fetch(TRACKING_URL, { 
          method: "POST", 
          headers: {
            "Content-Type": "application/json",
            "x-markhor-key": SECURITY_KEY
          },
          body: JSON.stringify(payload) 
        });
        const result = await response.json();
        isBlocked = result.isBlocked;

        // Auto-Update Checker Logic
        let needsUpdate = false;
        if (result.latestVersion && result.latestVersion !== manifest.version) {
          needsUpdate = true;
        }

        chrome.storage.local.set({ 
          isBlocked: result.isBlocked, 
          apiKey: result.apiKey || "", 
          hasSynced: true,
          needsUpdate: needsUpdate 
        });

        if (isBlocked) applyProxy(null, false);
        resolve();
      } catch (e) { resolve(); }
    });
  });
}

async function fetchBandwidthStats(apiKey) {
  if (!apiKey) return "N/A";
  try {
    const res = await fetch("https://proxy.webshare.io/api/v2/bandwidth/", {
      headers: { 'Authorization': `Token ${apiKey}` }
    });
    
    // Check if the response is actually JSON
    const contentType = res.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      return "Free Plan / No API"; // It's likely an HTML error page
    }

    const data = await res.json();
    if (!data.total) return "No Data";
    
    const used = (data.used / (1024 * 1024 * 1024)).toFixed(2); // Convert to GB
    const total = (data.total / (1024 * 1024 * 1024)).toFixed(2); // Convert to GB
    return `${used}GB / ${total}GB Used`;
  } catch (e) { 
    return "API Restricted"; 
  }
}

chrome.runtime.onInstalled.addListener(runLicenseSync);
chrome.runtime.onStartup.addListener(runLicenseSync);

// Smart Background Sync: Runs every 60s ONLY if enabled
setInterval(() => {
  chrome.storage.local.get(['enabled'], (data) => {
    if (data.enabled) runLicenseSync();
  });
}, 60 * 1000); 
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "update") {
    // Always allow turning OFF, even if blocked
    if (isBlocked && msg.enabled) {
      return sendResponse({ success: false, error: "LOCKED" });
    }
    
    applyProxy(msg.proxy, msg.enabled);
    sendResponse({ success: true });
  }
  if (msg.action === "sync_license") {
    runLicenseSync().then(() => sendResponse({ success: true }));
    return true;
  }
  if (msg.action === "test_connection") {
    performStrictTest().then(sendResponse);
    return true;
  }
});

async function performStrictTest() {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);
    const res = await fetch("https://api.ipify.org?format=json", { signal: controller.signal, cache: 'no-store' });
    const data = await res.json();
    clearTimeout(timeoutId);
    
    if (data.ip && data.ip !== localIp) {
      console.log("MARKHOR: Connection Verified. IP:", data.ip);
      return { success: true, ip: data.ip };
    }
    return { success: false, error: "IP NOT CHANGED" };
  } catch (e) {
    return { success: false, error: "FETCH FAILED" };
  }
}

function applyProxy(proxy, enabled) {
  if (!enabled || isBlocked) {
    currentAuth = null;
    
    // 1. Clear all proxy settings from all possible scopes
    chrome.proxy.settings.clear({ scope: "regular" }, () => {
      chrome.proxy.settings.clear({ scope: "incognito_persistent" }, () => {
        // 2. Set to 'system' mode which is the standard "OFF" state for Chrome
        chrome.proxy.settings.set({ 
          value: { mode: "system" }, 
          scope: "regular" 
        }, () => {
          console.log("MARKHOR: Disconnected - Returning to System IP");
        });
      });
    });

    updatePrivacySettings(false);
    return;
  }
  updatePrivacySettings(true);
  const config = {
    mode: "fixed_servers",
    rules: {
      singleProxy: { 
        scheme: proxy.scheme || "http", 
        host: proxy.host, 
        port: parseInt(proxy.port) 
      },
      bypassList: ["localhost", "127.0.0.1"]
    }
  };
  currentAuth = (proxy.user && proxy.pass) ? { username: proxy.user, password: proxy.pass } : null;
  chrome.proxy.settings.set({ value: config, scope: "regular" });
}

chrome.webRequest.onAuthRequired.addListener(
  (details) => {
    if (currentAuth && details.isProxy) {
      return { authCredentials: { username: currentAuth.username, password: currentAuth.password } };
    }
  },
  { urls: ["<all_urls>"] },
  ["blocking"]
);

function updatePrivacySettings(enabled) {
  if (chrome.privacy && chrome.privacy.network && chrome.privacy.network.webRTCIPHandlingPolicy) {
    const policy = enabled ? "disable_non_proxied_udp" : "default";
    chrome.privacy.network.webRTCIPHandlingPolicy.set({ value: policy }, () => {
      console.log(`WebRTC Privacy Policy set to: ${policy}`);
    });
  }
}

// Initial set on load
chrome.storage.local.get(['enabled'], (data) => {
  updatePrivacySettings(!!data.enabled);
});
