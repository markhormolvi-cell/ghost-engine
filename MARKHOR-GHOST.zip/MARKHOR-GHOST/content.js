// Content script disabled to match FoxyProxy behavior.
