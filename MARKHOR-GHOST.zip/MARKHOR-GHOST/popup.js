document.addEventListener('DOMContentLoaded', () => {
  const masterSwitch = document.getElementById('masterSwitch');
  const logoToggle = document.getElementById('logoToggle');
  const flipper = document.getElementById('flipper');
  const statusText = document.getElementById('statusText');
  const lockedScreen = document.getElementById('lockedScreen');
  const updateScreen = document.getElementById('updateScreen');
  const mainApp = document.getElementById('mainApp');
  const displayDeviceId = document.getElementById('displayDeviceId');
  const errorModal = document.getElementById('errorModal');
  const syncOverlay = document.getElementById('syncOverlay');

  let proxies = [];
  let currentIndex = 0;
  let isBlocked = true;
  let needsUpdate = false;

  // 1. Initial State Check (Instant UI)
  chrome.storage.local.get(['proxies', 'currentIndex', 'enabled', 'isBlocked', 'deviceId', 'lastSyncTime', 'needsUpdate'], (data) => {
    const now = Date.now();
    const cooldown = 24 * 60 * 60 * 1000;
    const lastSync = data.lastSyncTime || 0;
    const isRecent = (now - lastSync < cooldown);

    // Initial Data Setup
    isBlocked = data.isBlocked !== false;
    needsUpdate = data.needsUpdate === true;
    proxies = data.proxies || [];
    currentIndex = data.currentIndex || 0;
    if (displayDeviceId) displayDeviceId.textContent = data.deviceId || "FINGERPRINTING...";

    // If synced recently, show UI immediately and hide overlay
    if (isRecent) {
      if (syncOverlay) syncOverlay.style.display = 'none'; // Instant hide
      updateUIVisibility();
      if (!isBlocked) {
        masterSwitch.checked = !!data.enabled;
        if (masterSwitch.checked) {
          logoToggle.classList.add('active');
          updateStatusUI(true);
        } else {
          statusText.textContent = "SYSTEM IDLE. STEALTH ENGINE READY. 🌑";
        }
      }
    }

    // 2. Background Sync (Silent or Overlay if needed)
    chrome.runtime.sendMessage({ action: "sync_license" }, (response) => {
      chrome.storage.local.get(['isBlocked', 'enabled', 'lastSyncTime', 'needsUpdate'], (freshData) => {
        isBlocked = freshData.isBlocked !== false;
        needsUpdate = freshData.needsUpdate === true;
        updateUIVisibility();

        if (!isBlocked && !needsUpdate) {
          chrome.storage.local.set({ lastSyncTime: Date.now() });
        }

        // Only handle overlay if it was actually showing
        if (syncOverlay && !isRecent) {
          setTimeout(() => {
            syncOverlay.classList.remove('active');
            setTimeout(() => { syncOverlay.style.display = 'none'; }, 500);
          }, 1000);
        }
      });
    });
  });

  function updateUIVisibility() {
    // Priority 1: Force Update
    if (needsUpdate) {
      updateScreen.style.display = 'flex';
      lockedScreen.classList.remove('active');
      mainApp.classList.remove('active');
      return;
    }
    updateScreen.style.display = 'none';

    // Priority 2: License Block
    if (isBlocked) {
      lockedScreen.classList.add('active');
      mainApp.classList.remove('active');
    } else {
      lockedScreen.classList.remove('active');
      mainApp.classList.add('active');
    }
  }

  function showModal(msg) {
    if (errorModal) {
      errorModal.style.display = "flex";
      if (msg.includes("GARR BARR") || msg.includes("API Key") || msg.includes("LICENSE")) {
        document.getElementById('modalMsg').textContent = "ADMIN KO BOLO K KUCH GARR BARR HAI RAY BABA";
      } else {
        document.getElementById('modalMsg').textContent = msg;
      }
    }
  }

  const contactAdminBtn = document.getElementById('contactAdminBtn');
  if (contactAdminBtn) {
    contactAdminBtn.onclick = () => { errorModal.style.display = "none"; };
  }

  logoToggle.onclick = () => {
    if (isBlocked) return;
    masterSwitch.checked = !masterSwitch.checked;
    masterSwitch.onchange(); 
  };

  masterSwitch.onchange = async () => {
    if (isBlocked) { masterSwitch.checked = false; return; }
    const isEnabled = masterSwitch.checked;
    chrome.storage.local.set({ enabled: isEnabled });

    if (isEnabled) {
      flipper.classList.add('rotating');
      logoToggle.classList.remove('active');
      startProxyConnection();
    } else {
      flipper.classList.remove('rotating');
      logoToggle.classList.remove('active');
      await updateBackground(null, false);
      updateStatusUI(false);
      console.log("MARKHOR: Disconnect signal sent.");
    }
  };

  async function startProxyConnection() {
    const searchPhrases = [
      "Awakening the Ghost Mode... 🌑",
      "Vanishing from the grid... 🌫️",
      "Becoming untraceable... ✨"
    ];
    let phraseIdx = 0;
    statusText.style.color = "#fff";

    try {
      const storage = await new Promise(r => chrome.storage.local.get(['apiKey'], r));
      const API_KEY = storage.apiKey;
      if (!API_KEY || API_KEY === "") throw new Error("ADMIN KO BOLO K KUCH GARR BARR HAI RAY BABA");

      statusText.textContent = searchPhrases[0];
      if (proxies.length === 0) {
        proxies = await fetchUSAProxies(API_KEY);
      }
      if (proxies.length === 0) throw new Error("GHOST UNAVAILABLE");

      let foundWorking = false;
      let attempts = 0;
      const maxAttempts = 30;

      while (masterSwitch.checked && !foundWorking && attempts < maxAttempts) {
        const activeProxy = proxies[currentIndex];
        if (!masterSwitch.checked) break;

        await typeWriter(statusText, searchPhrases[phraseIdx], 30);
        if (!masterSwitch.checked) break;

        phraseIdx = (phraseIdx + 1) % searchPhrases.length;
        await updateBackground(activeProxy, true);
        
        for (let i = 0; i < 20; i++) {
          if (!masterSwitch.checked) break;
          await new Promise(r => setTimeout(r, 100));
        }

        if (!masterSwitch.checked) break;
        const testResult = await new Promise(r => chrome.runtime.sendMessage({ action: "test_connection" }, r));
        
        if (testResult && testResult.success) {
          foundWorking = true;
          chrome.storage.local.set({ activeProxy, proxies });
          updateStatusUI(true);
        } else {
          attempts++;
          currentIndex = (currentIndex + 1) % proxies.length;
          chrome.storage.local.set({ currentIndex });
        }
      }

      if (masterSwitch.checked && !foundWorking) {
        throw new Error("GHOST DISRUPTED: Contact Admin.");
      }
    } catch (err) {
      masterSwitch.checked = false;
      chrome.storage.local.set({ enabled: false });
      updateBackground(null, false);
      statusText.textContent = "GHOST FAILED";
      statusText.style.color = "#ff3131";
      showModal(err.message);
    }
  }

  async function fetchUSAProxies(apiKey) {
    try {
      await updateBackground(null, false);
      await new Promise(r => setTimeout(r, 1200)); 
      const res = await fetch(`https://proxy.webshare.io/api/v2/proxy/list/?mode=direct&country_code__in=US`, {
        headers: { 'Authorization': `Token ${apiKey}` }
      });
      const data = await res.json();
      const results = (data.results || []).filter(p => p.valid !== false).map(p => ({
        id: p.id, host: p.proxy_address, port: p.port, scheme: 'http', user: p.username, pass: p.password
      }));
      chrome.storage.local.set({ proxies: results });
      return results;
    } catch (e) { return proxies; }
  }

  function updateStatusUI(enabled) {
    if (enabled) {
      flipper.classList.remove('rotating');
      logoToggle.classList.add('active');
      statusText.textContent = "YOU ARE NOW A GHOST. TOTAL STEALTH ACTIVE. 🛡️🔥";
      statusText.style.color = "var(--primary)";
      statusText.classList.add('pulse');
    } else {
      flipper.classList.remove('rotating');
      logoToggle.classList.remove('active');
      statusText.textContent = "RETURNING TO SHADOWS. GHOST MODE IDLE.";
      statusText.style.color = "var(--primary)";
      statusText.classList.remove('pulse');
    }
  }

  function typeWriter(element, text, speed = 40) {
    return new Promise(resolve => {
      let i = 0;
      element.textContent = "";
      function type() {
        if (i < text.length) {
          element.textContent += text.charAt(i);
          i++;
          setTimeout(type, speed);
        } else {
          resolve();
        }
      }
      type();
    });
  }

  function updateBackground(proxy, enabled) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ action: "update", proxy, enabled }, resolve);
    });
  }
});
