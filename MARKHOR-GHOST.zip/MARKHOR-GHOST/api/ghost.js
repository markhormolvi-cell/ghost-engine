// MARKHOR - GHOST ENGINE (V3 - JSON STANDARD)
export default async function handler(req, res) {
  const GAS_URL = process.env.GAS_URL;
  const SECRET_KEY = "MARKHOR_SECURE_2024";

  // 1. CORS Headers
  res.setHeader('Access-Control-Allow-Credentials', true);
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,OPTIONS,PATCH,DELETE,POST,PUT');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'X-CSRF-Token, X-Requested-With, Accept, Accept-Version, Content-Length, Content-MD5, Content-Type, Date, X-Api-Version, x-markhor-key'
  );

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // 2. Security Check
  if (req.headers['x-markhor-key'] !== SECRET_KEY) {
    return res.status(403).json({ success: false, error: "Access Denied" });
  }

  try {
    const LATEST_VERSION = "1.0"; // Change this to push a force update

    // 3. Forward to Google Apps Script
    const response = await fetch(GAS_URL, {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify(req.body),
      redirect: "follow"
    });

    const data = await response.json();
    
    // Inject the latest version into the response
    data.latestVersion = LATEST_VERSION;

    res.status(200).json(data);
  } catch (error) {
    res.status(500).json({ success: false, error: "Ghost System Error: " + error.message });
  }
}
