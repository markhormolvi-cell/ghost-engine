(function() {
    const scriptTag = document.currentScript;
    const spoofedTimezone = scriptTag ? scriptTag.dataset.timezone : 'America/Los_Angeles';

    console.log(`[MARKHOR GHOST] Stealth Engine Active. Timezone: ${spoofedTimezone}`);

    // --- 1. TIMEZONE & DATE SPOOFING ---

    const OriginalDateTimeFormat = Intl.DateTimeFormat;
    const OriginalDate = Date;

    // Override Intl.DateTimeFormat
    function PatchedDateTimeFormat(locale, options) {
        if (!(this instanceof PatchedDateTimeFormat)) {
            return OriginalDateTimeFormat(locale, options);
        }
        const newOptions = Object.assign({}, options);
        if (!newOptions.timeZone) {
            newOptions.timeZone = spoofedTimezone;
        }
        return new OriginalDateTimeFormat(locale, newOptions);
    }
    PatchedDateTimeFormat.prototype = OriginalDateTimeFormat.prototype;
    PatchedDateTimeFormat.supportedLocalesOf = OriginalDateTimeFormat.supportedLocalesOf;
    Intl.DateTimeFormat = PatchedDateTimeFormat;

    // Override resolvedOptions
    const originalResolvedOptions = OriginalDateTimeFormat.prototype.resolvedOptions;
    OriginalDateTimeFormat.prototype.resolvedOptions = function() {
        const resolved = originalResolvedOptions.call(this);
        return Object.assign({}, resolved, { timeZone: spoofedTimezone });
    };

    // Override Date.prototype methods for string representation
    const formatter = new OriginalDateTimeFormat('en-US', {
        timeZone: spoofedTimezone,
        hour12: false,
        year: 'numeric', month: 'short', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit',
        timeZoneName: 'long'
    });

    const weekdayFormatter = new OriginalDateTimeFormat('en-US', {
        timeZone: spoofedTimezone,
        weekday: 'short'
    });

    Date.prototype.toString = function() {
        const parts = formatter.formatToParts(this);
        const weekday = weekdayFormatter.format(this);
        const map = {};
        parts.forEach(p => map[p.type] = p.value);
        
        // Format: "Sat May 09 2026 02:22:25 GMT+0500 (Pakistan Standard Time)"
        // Note: The GMT offset calculation is tricky, we'll simplify or use a better method if needed
        // For now, let's just use the formatted parts to build a plausible string
        const timeStr = `${map.hour}:${map.minute}:${map.second}`;
        const dateStr = `${weekday} ${map.month} ${map.day} ${map.year}`;
        
        // Get offset string like GMT-0700
        const offset = -this.getTimezoneOffset();
        const absOffset = Math.abs(offset);
        const h = Math.floor(absOffset / 60).toString().padStart(2, '0');
        const m = (absOffset % 60).toString().padStart(2, '0');
        const sign = offset >= 0 ? '+' : '-';
        const gmtStr = `GMT${sign}${h}${m}`;
        
        return `${dateStr} ${timeStr} ${gmtStr} (${map.timeZoneName})`;
    };

    // Override getTimezoneOffset
    Date.prototype.getTimezoneOffset = function() {
        const date = new OriginalDate(this.getTime());
        const isoStr = date.toLocaleString('en-US', { timeZone: spoofedTimezone, hour12: false });
        const parts = isoStr.match(/(\d+)\/(\d+)\/(\d+), (\d+):(\d+):(\d+)/);
        if (!parts) return 0;
        
        const [_, m, d, y, hr, min, sec] = parts;
        const localDate = new OriginalDate(y, m - 1, d, hr, min, sec);
        return Math.round((date.getTime() - localDate.getTime()) / 60000);
    };

    // --- 2. HARDWARE SPOOFING ---

    try {
        Object.defineProperty(navigator, 'hardwareConcurrency', { get: () => 8 });
        Object.defineProperty(navigator, 'deviceMemory', { get: () => 8 });
        Object.defineProperty(navigator, 'platform', { get: () => 'Win32' });
        Object.defineProperty(navigator, 'maxTouchPoints', { get: () => 0 });
    } catch (e) {}

    // --- 3. SCREEN SPOOFING ---

    const spoofScreen = {
        width: 1920,
        height: 1080,
        availWidth: 1920,
        availHeight: 1040,
        colorDepth: 24,
        pixelDepth: 24
    };

    try {
        for (let prop in spoofScreen) {
            Object.defineProperty(Screen.prototype, prop, { get: () => spoofScreen[prop] });
            Object.defineProperty(window.screen, prop, { get: () => spoofScreen[prop] });
        }
        Object.defineProperty(window, 'innerWidth', { get: () => 1920 });
        Object.defineProperty(window, 'innerHeight', { get: () => 937 });
    } catch (e) {}

    // --- 4. WEBGL RENDERER SPOOFING (SUBTLE) ---
    // We want to avoid the "Microsoft Basic Render Driver" which looks like a VM
    const originalGetParameter = WebGLRenderingContext.prototype.getParameter;
    WebGLRenderingContext.prototype.getParameter = function(parameter) {
        // UNMASKED_VENDOR_WEBGL
        if (parameter === 0x9245) return "Google Inc. (NVIDIA)";
        // UNMASKED_RENDERER_WEBGL
        if (parameter === 0x9246) return "ANGLE (NVIDIA, NVIDIA GeForce RTX 3060 Direct3D11 vs_5_0 ps_5_0, D3D11)";
        return originalGetParameter.call(this, parameter);
    };

    // --- 5. CANVAS PROTECTOR ---
    const originalGetImageData = CanvasRenderingContext2D.prototype.getImageData;
    CanvasRenderingContext2D.prototype.getImageData = function(x, y, w, h) {
        const imageData = originalGetImageData.apply(this, arguments);
        // Add extremely subtle noise to the first pixel if it's not transparent
        if (imageData.data[3] > 0) {
            imageData.data[0] = (imageData.data[0] + 1) % 256;
        }
        return imageData;
    };

})();
